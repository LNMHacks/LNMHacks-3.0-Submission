import warnings
warnings.warn(
'''Use

from mahotas.features import texture
''', DeprecationWarning)

from mahotas.features.texture import *
