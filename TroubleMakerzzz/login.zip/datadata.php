<form method="post" action="dataentry.php">
Book Name<input type="text" name="book_name">
author<input type="text" name="author">
<br>
<button type="submit" value="Submit">Submit</button>
</form>